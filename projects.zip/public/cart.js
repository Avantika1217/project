// NAVIGATION SECTION 

const bar = document.getElementById('bar');
const close = document.getElementById('close');
const nav = document.getElementById('navbar');

if(bar){
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    })
}

if(close){
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    })
}

// CART SECTION 

function updateCart() {
    const cartItems = document.querySelectorAll('.cart-item');
    let subtotal = 0;
    cartItems.forEach(item => {
        const price = parseFloat(item.querySelector('.price').textContent.replace('$', ''));
        const quantity = item.querySelector('.quantity').value;
        const total = price * quantity;
        item.querySelector('.total').textContent = `$${total.toFixed(2)}`;
        subtotal += total;
    });

    const shipping = 5.00;
    const total = subtotal + shipping;

    document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('shipping').textContent = `$${shipping.toFixed(2)}`;
    document.getElementById('total').textContent = `$${total.toFixed(2)}`;
}

function removeItem(itemId) {
    const item = document.getElementById(itemId);
    item.remove();
    updateCart();
}

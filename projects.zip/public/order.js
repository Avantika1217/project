document.getElementById('orderForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const product = document.getElementById('product').value;
    const quantity = document.getElementById('quantity').value;
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;

    if (!name || !address || !product || !quantity) {
        alert('Please fill out all fields!');
        return;
    }

    let price = 0;
    if (product === "T-Shirt") price = 10;
    else if (product === "Jeans") price = 30;
    else if (product === "Jacket") price = 50;

    const total = price * quantity;

    try {
        console.log('Sending order data:', { name, address, product, quantity, total }); // Debugging

        const response = await fetch('http://localhost:5000/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, address, product, quantity, total }),
        });

        console.log('Response received:', response); // Debugging

        const result = await response.json();

        if (response.ok) {
            alert(`Order placed successfully!\n\nOrder Summary:\nName: ${name}\nAddress: ${address}\nProduct: ${product}\nQuantity: ${quantity}\nTotal: ${total} USD`);
            document.getElementById('orderForm').reset();
        } else {
            console.error('Error response from server:', result);
            alert(result.error || 'Failed to place the order. Please try again.');
        }
    } catch (error) {
        console.error('Error placing order:', error);
        alert('An error occurred. Please try again later.');
    }
});
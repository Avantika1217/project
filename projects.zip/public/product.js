// JavaScript to handle image thumbnail switching
const thumbnails = document.querySelectorAll('.small-img-col');
const mainImage = document.getElementById('small-img-group');

thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', (e) => {
        mainImage.src = e.target.src;
    });
});

// Add to Cart function
async function buynow() {
    const size = document.getElementById('size').value;
    const quantity = document.getElementById('quantity').value;

    if (!size || !quantity) {
        alert('Please select a size and quantity.');
        return;
    }

    try {
        // Send product data to the backend using fetch
        const response = await fetch('/api/cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ size, quantity }),
        });

        const result = await response.json();

        if (response.ok) {
            alert(`Added ${quantity} x ${size} shirt to your cart.`);
        } else {
            alert(result.error || 'Failed to add the product to the cart. Please try again.');
        }
    } catch (error) {
        console.error('Error adding product to cart:', error);
        alert('An error occurred. Please try again later.');
    }
}
// NAVIGATION SECTION 

const bar = document.getElementById('bar');
const close = document.getElementById('close');
const nav = document.getElementById('navbar');

if(bar){
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    })
}

if(close){
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    })
}


// Simple Scroll Animation (Fade-in effect)
window.addEventListener('scroll', function() {
    const aboutSection = document.querySelector('.about-intro');
    const storySection = document.querySelector('.our-story');
    
    // Adding 'fade-in' class when the section scrolls into view
    if (window.scrollY > aboutSection.offsetTop - window.innerHeight + 150) {
      aboutSection.classList.add('fade-in');
    }
  
    if (window.scrollY > storySection.offsetTop - window.innerHeight + 150) {
      storySection.classList.add('fade-in');
    }
  });
  
  document.addEventListener('DOMContentLoaded', function() {
    const aboutSection = document.querySelector('.about-intro');
    const storySection = document.querySelector('.our-story');
  
    aboutSection.classList.add('fade-in');
    storySection.classList.add('fade-in');
  });
  
  // Adding 'fade-in' class to smooth the appearance of sections
  const style = document.createElement('style');
  style.innerHTML = `
    .fade-in {
      opacity: 1;
      transition: opacity 1s ease-in;
    }
    .about-intro, .our-story {
      opacity: 0;
    }
  `;
  document.head.appendChild(style);
